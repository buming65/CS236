pip install pyspark
spark-submit CS236.py $1 $2 $3